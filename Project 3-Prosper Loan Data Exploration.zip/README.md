# (Loan Data Exploration)
## by Adekola


## Prosper Dataset

> The data set contains 113,937 loans with 81 variables on each loan, including loan amount, borrower rate (or interest rate), current loan status, borrower income, and many others. The data contain data about the loans from quarter four in 2005 to quarter one in 2014. I will be exploring a subset of this dataset.


## Summary of Findings

> Loan original take on a very large range of values from about 1000USD at the lowest to about 35000USD at the highest. Plotted on a logarithmic scale, the distribution of loan amount takes on a multi-modal shape with its highest peak at around 4000USD.
> Borrower's APR has a multimodal distribution, With very High peaks between 36% and 37%.
> The CreditScoreRange shows a left skewed distribution with less entries on Lower Credit Scores, the highest peak is at range 680-699 with 14.8% entries.
> The Employment Status shows that about 60.6% of borrowers are employed, 0.7% are retired and only 0.7% are not employed
> Most of the borrower's APR of completed loans are less than 26% and the past due are above 29%.
> The Loan status shows that about 51.0% of loans are in the current status, about 32.8% of loans are completed, 10.3% of loans are charged off, and about 4% are defaulted.
> Credit Score shows a nagative interaction with the Borrower's APR, the lower the credit score, the higher the borrower's APR
> Credit score have a positve correlation with Loan amount, higher credit score have higher loan amount, and also most of the completed loan status are less than 8000USD.

## Key Insights for Presentation

> For my presentation I decided to first look at the individaul distributions of the Loan Original Amount, Borrower's APR, Credit Score, Loan Statu and Employment Status on how there were represented in the dataset. 
> Finally I presented the Borrower's APR vs. Credit Score, Borrower's APR vs. Credit Score vs. Loan Status, Loan Amount vs. Employment Status vs. Loan Status plots which was aimed at looking how each of these three factors related to one to another. 